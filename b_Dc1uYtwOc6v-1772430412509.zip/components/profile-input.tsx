"use client"

import { useState, useRef } from "react"
import { Link, Upload, ArrowRight, FileText, X } from "lucide-react"

export function ProfileInput() {
  const [url, setUrl] = useState("")
  const [fileName, setFileName] = useState<string | null>(null)
  const [isFocused, setIsFocused] = useState(false)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file && file.type === "application/pdf") {
      setFileName(file.name)
      setUrl("")
    }
  }

  const clearFile = () => {
    setFileName(null)
    if (fileInputRef.current) {
      fileInputRef.current.value = ""
    }
  }

  const handleSubmit = () => {
    if (!url && !fileName) return
    const target = document.getElementById("scorecard")
    target?.scrollIntoView({ behavior: "smooth" })
  }

  return (
    <div className="mx-auto w-full max-w-2xl">
      <div
        className={`relative flex items-center gap-3 rounded-lg border bg-card p-2 transition-all duration-200 ${
          isFocused
            ? "border-primary shadow-[0_0_20px_rgba(56,132,255,0.15)]"
            : "border-border"
        }`}
      >
        {fileName ? (
          <div className="flex flex-1 items-center gap-3 rounded-md bg-secondary px-4 py-3">
            <FileText className="h-5 w-5 shrink-0 text-primary" />
            <span className="flex-1 truncate font-mono text-sm text-foreground">
              {fileName}
            </span>
            <button
              onClick={clearFile}
              className="shrink-0 text-muted-foreground transition-colors hover:text-foreground"
              aria-label="Eliminar archivo"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <>
            <div className="flex items-center pl-3">
              <Link className="h-5 w-5 text-muted-foreground" />
            </div>
            <input
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              onFocus={() => setIsFocused(true)}
              onBlur={() => setIsFocused(false)}
              placeholder="linkedin.com/in/tu-perfil"
              className="flex-1 bg-transparent py-3 font-mono text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
              aria-label="URL de perfil de LinkedIn"
            />
            <div className="flex items-center gap-2">
              <button
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-2 rounded-md border border-border px-3 py-2 text-xs text-muted-foreground transition-all hover:border-primary/50 hover:text-foreground"
                aria-label="Subir PDF"
              >
                <Upload className="h-4 w-4" />
                <span className="hidden sm:inline">PDF</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf"
                onChange={handleFileChange}
                className="hidden"
                aria-label="Seleccionar archivo PDF"
              />
            </div>
          </>
        )}
        <button
          onClick={handleSubmit}
          disabled={!url && !fileName}
          className="flex shrink-0 items-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-medium text-primary-foreground transition-all hover:brightness-110 disabled:opacity-30 disabled:hover:brightness-100"
          aria-label="Analizar perfil"
        >
          <span className="hidden sm:inline">Analizar</span>
          <ArrowRight className="h-4 w-4" />
        </button>
      </div>
      <p className="mt-3 text-center font-mono text-xs text-muted-foreground">
        {'Pega la URL de tu perfil de LinkedIn o sube tu CV en PDF'}
      </p>
    </div>
  )
}
